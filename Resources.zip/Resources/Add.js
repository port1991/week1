exports.editWindow = function() {

var done = Ti.UI.createButton({

		systemButton : Ti.UI.iPhone.SystemButton.ADD
	});

	var cancel = Ti.UI.createButton({

		systemButton : Ti.UI.iPhone.SystemButton.CANCEL
	});

	var mainMain = Ti.UI.createWindow({
		backgroundColor : "#fff",
		layout : 'vrtical',
		title : "Add",
		rightNavButton : done,
		leftNavButton : cancel,
	});
	
	var win1 = Titanium.UI.iOS.createNavigationWindow({
		window : mainMain

	});
	
	// Create a TextField.
	var aTextField = Ti.UI.createTextField({
		height : 35,
		top : 80,
		left : 40,
		width : 240,
		hintText : 'Enter Name',
		keyboardType : Ti.UI.KEYBOARD_DEFAULT,
		returnKeyType : Ti.UI.RETURNKEY_DEFAULT,
		borderStyle : Ti.UI.INPUT_BORDERSTYLE_ROUNDED
	});
		// Listen for return events.
	aTextField.addEventListener('return', function(e) {
		aTextField.blur();
	});
	
	
			// Create a TextField.
	var aTextField2 = Ti.UI.createTextField({
		height : 35,
		top : 110,
		left : 40,
		width : 240,
		hintText : 'Enter short Description',
		keyboardType : Ti.UI.KEYBOARD_DEFAULT,
		returnKeyType : Ti.UI.RETURNKEY_DEFAULT,
		borderStyle : Ti.UI.INPUT_BORDERSTYLE_ROUNDED
	});

		// Listen for return events.
	aTextField2.addEventListener('return', function(e) {
		aTextField2.blur();
	});
	
	
	
	done.addEventListener('click', function() {
		alert("botton clicked working");
		
		/*var db = Ti.Database.open('DemoDatabse');
	//Ti.API.info('INSERT INTO "main"."Table1" ("name","discription") VALUES (?,?)', aTextField.value, aTextField2.value);
	db.execute('INSERT INTO "main"."Table1" ("name","discription") VALUES (?,?)', aTextField.value, aTextField2.value);
	db.close();
	win.close();*/
	});

	cancel.addEventListener('click', function() {
		win1.close();
	});
	
	win1.open();
	win1.add(aTextField);
	win1.add(aTextField2);
	
/*var win = Ti.UI.currentWindow;

// Create a TextField.
var aTextField = Ti.UI.createTextField({
	height : 35,
	top : 40,
	left : 40,
	width : 240,
	hintText : 'Enter Name',
	keyboardType : Ti.UI.KEYBOARD_DEFAULT,
	returnKeyType : Ti.UI.RETURNKEY_DEFAULT,
	borderStyle : Ti.UI.INPUT_BORDERSTYLE_ROUNDED
});

// Listen for return events.
aTextField.addEventListener('return', function(e) {
	aTextField.blur();
});

// Add to the parent view.
//win.add(aTextField);
// Create a TextField.
var aTextField2 = Ti.UI.createTextField({
	height : 35,
	top : 80,
	left : 40,
	width : 240,
	hintText : 'Enter Discription',
	keyboardType : Ti.UI.KEYBOARD_DEFAULT,
	returnKeyType : Ti.UI.RETURNKEY_DEFAULT,
	borderStyle : Ti.UI.INPUT_BORDERSTYLE_ROUNDED
});

// Listen for return events.
aTextField2.addEventListener('return', function(e) {
	aTextField2.blur();
});

// Add to the parent view.
//win.add(aTextField2);

// Create a Button.
var aButton = Ti.UI.createButton({
	title : 'ADD',
	height : 50,
	width : 100,
	top : 150,
	//left : myLeft
});

// Listen for click events.
aButton.addEventListener('click', function() {
	//alert('\'aButton\' was clicked!');

	var db = Ti.Database.open('DemoDatabse');
	//Ti.API.info('INSERT INTO "main"."Table1" ("name","discription") VALUES (?,?)', aTextField.value, aTextField2.value);
	db.execute('INSERT INTO "main"."Table1" ("name","discription") VALUES (?,?)', aTextField.value, aTextField2.value);
	db.close();
	win.close();

});

// Add to the parent view.
//win.add(aButton);
};*/

};
